import boto3

region = "us-east-1"

def lambda_handler(event, context):
    pass
